import React from 'react'

function Avatar() {
    let url = 'https://i.pravatar.cc/150?img=39'
    
    return <img src={url}/>
}

export default Avatar