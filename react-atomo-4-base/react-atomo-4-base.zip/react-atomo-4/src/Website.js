import React from 'react';

function Website() {
  return (
      <h1>Holis mundo!!!</h1>
    );
}

export default Website;
